# Portable Reference Assemblies

This repository contains the reference assemblies that are used by
portable class libraries.

## Versioning

We're using tags to indicate which Visual Studio version they're
applicable to, for example:

	Visual-Studio-2013
	Visual-Studio-2013-Update2