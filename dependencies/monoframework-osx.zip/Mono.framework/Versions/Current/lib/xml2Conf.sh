#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/Library/Frameworks/Mono.framework/Versions/4.0.3/lib"
XML2_LIBS="-lxml2 -lz -lpthread  -liconv -lm "
XML2_INCLUDEDIR="-I/Library/Frameworks/Mono.framework/Versions/4.0.3/include/libxml2"
MODULE_VERSION="xml2-2.9.1"

